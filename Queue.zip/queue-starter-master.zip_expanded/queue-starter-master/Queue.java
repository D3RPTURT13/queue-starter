/*
 * This is the class that implements the queue data structure.
 * You may decide what data structure to use to implement it.
 */
import java.util.*;
public class Queue {
	private Node head;
	private Node tail;
	/*
	 * The constructor creates an empty list.
	 */
	public Queue() {
		head = null;
	}
	
	/*
	 * This method creates a new node and adds it to the tail of the list.
	 */
	public void enqueue(String data) {
		Node newNode = new Node();
		newNode = null;
		if (head == null){
			head = newNode;
			tail = newNode;
		} else {
		tail.next = newNode;
		tail=newNode;
		newNode.record = data;
	}	
		}
	
	/*
	 * This method deletes the first node in the list.
	 */
	public void dequeue() {
		if (head == null){
            System.out.println("Deletion not neccessary or possible");
		} else {
            if (head == tail) {
                  head = null;
                  tail = null;
            } else {
                  head = head.next;
            }
      }
	}
	
	/*
	 * This method transverses the list and prints out the record in each node.
	 */
	public void printQueue() {
		Node pointer = head;
		while (pointer != null) {
			System.out.println(pointer.record);
			pointer = pointer.next;
		}
		System.out.println();
	}
	
}
